The following files were generated for 'chipscope_icon_0' in directory
C:\Users\joshuas2\Desktop\427\implementation\chipscope_icon_0_wrapper\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * chipscope_icon_0.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * chipscope_icon_0.ejp
   * chipscope_icon_0.ngc
   * chipscope_icon_0_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * chipscope_icon_0.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * chipscope_icon_0.gise
   * chipscope_icon_0.xise

Deliver Readme:
   Readme file for the IP.

   * chipscope_icon_0_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * chipscope_icon_0_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

