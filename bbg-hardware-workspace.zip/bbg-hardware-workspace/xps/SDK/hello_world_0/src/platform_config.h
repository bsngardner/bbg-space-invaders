#ifndef __PLATFORM_CONFIG_H_
#define __PLATFORM_CONFIG_H_

#ifdef __PPC__
#define CACHEABLE_REGION_MASK 0x80000080
#endif

#endif
