#include "xgpio.h"          // Provides access to PB GPIO driver.
#include <stdio.h>          // xil_printf and so forth.
#include "platform.h"       // Enables caching and other system stuff.
#include "mb_interface.h"   // provides the microblaze interrupt enables, etc.
#include "xintc_l.h"        // Provides handy macros for the interrupt controller.
#include "rtc.h"

XGpio gpLED; // This is a handle for the LED GPIO block.
XGpio gpPB; // This is a handle for the push-button GPIO block.

u32 currentButtonState;

//Defines
#define HOUR_BTN 0x08	//bit mask for hour button
#define MIN_BTN 0x01	//bit mask for minute button
#define SEC_BTN 0x02	//bit mask for second button
#define UP_BTN 0x10		//bit mask for up button
#define DOWN_BTN 0x04	//bit mask for down button
#define DEBOUNCE_TIME 4	//40ms debounce
volatile u16 debounce_cnt = 0; //count variable for debouncing

// This is invoked in response to a timer interrupt.
// It does 2 things: 1) debounce switches, and 2) advances the time.
void timer_interrupt_handler() {
	//Once debouncing has finished, update button variable with button state
	if (debounce_cnt && !(--debounce_cnt)) { //'!!' makes a 0 remain 0 and nonzero become 1
		rtc_buttons.time.h = !!(currentButtonState & HOUR_BTN);
		rtc_buttons.time.m = !!(currentButtonState & MIN_BTN);
		rtc_buttons.time.s = !!(currentButtonState & SEC_BTN);
		rtc_buttons.u = !!(currentButtonState & UP_BTN);
		rtc_buttons.d = !!(currentButtonState & DOWN_BTN);

	}
	rtc_clock_tick(); //Call clock tick function

}

// This is invoked each time there is a change in the button state (result of a push or a bounce).
void pb_interrupt_handler() {
	// Clear the GPIO interrupt.
	XGpio_InterruptGlobalDisable(&gpPB); // Turn off all PB interrupts for now.
	currentButtonState = XGpio_DiscreteRead(&gpPB, 1); // Get the current state of the buttons.

	debounce_cnt = DEBOUNCE_TIME; //Initiate debouncing

	XGpio_InterruptClear(&gpPB, 0xFFFFFFFF); // Ack the PB interrupt.
	XGpio_InterruptGlobalEnable(&gpPB); // Re-enable PB interrupts.
}

// Main interrupt handler, queries the interrupt controller to see what peripheral
// fired the interrupt and then dispatches the corresponding interrupt handler.
// This routine acks the interrupt at the controller level but the peripheral
// interrupt must be ack'd by the dispatched interrupt handler.
// Question: Why is the timer_interrupt_handler() called after ack'ing the interrupt controller
// but pb_interrupt_handler() is called before ack'ing the interrupt controller?
void interrupt_handler_dispatcher(void* ptr) {
	XIntc_MasterDisable(XPAR_MICROBLAZE_0_INTC_BASEADDR);

	int intc_status = XIntc_GetIntrStatus(XPAR_INTC_0_BASEADDR);
	// Check the FIT interrupt first.
	if (intc_status & XPAR_FIT_TIMER_0_INTERRUPT_MASK) {
		XIntc_AckIntr(XPAR_INTC_0_BASEADDR, XPAR_FIT_TIMER_0_INTERRUPT_MASK);
		timer_interrupt_handler();
	}
	// Check the push buttons.
	if (intc_status & XPAR_PUSH_BUTTONS_5BITS_IP2INTC_IRPT_MASK) {
		pb_interrupt_handler();
		XIntc_AckIntr(XPAR_INTC_0_BASEADDR, XPAR_PUSH_BUTTONS_5BITS_IP2INTC_IRPT_MASK);
	}

	XIntc_MasterEnable(XPAR_MICROBLAZE_0_INTC_BASEADDR);
}

int main(void) {
	init_platform();
	// Initialize the GPIO peripherals.
	int success;
	//print("hello world");
	//Replace hello world with clock init message
	rtc_clock_init();

	success = XGpio_Initialize(&gpPB, XPAR_PUSH_BUTTONS_5BITS_DEVICE_ID);
	// Set the push button peripheral to be inputs.
	XGpio_SetDataDirection(&gpPB, 1, 0x0000001F);
	// Enable the global GPIO interrupt for push buttons.
	XGpio_InterruptGlobalEnable(&gpPB);
	// Enable all interrupts in the push button peripheral.
	XGpio_InterruptEnable(&gpPB, 0xFFFFFFFF);

	microblaze_register_handler(interrupt_handler_dispatcher, NULL);
	XIntc_EnableIntr(XPAR_INTC_0_BASEADDR,
			(XPAR_FIT_TIMER_0_INTERRUPT_MASK | XPAR_PUSH_BUTTONS_5BITS_IP2INTC_IRPT_MASK));
	XIntc_MasterEnable(XPAR_INTC_0_BASEADDR);
	microblaze_enable_interrupts();

	while (1)
		; // Program never ends.

	cleanup_platform();

	return 0;
}
