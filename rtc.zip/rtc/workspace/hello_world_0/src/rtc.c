/*
 * Real time clock implemented on XILINX ATLYS Spartan 6 board
 * 
 * Broderick Gardner
 * Benjamin Gardner
 */

#include "rtc.h"
#include <stdio.h>
#include <stdbool.h>

#define INIT_MESSAGE "24 Hour clock\n\n\r"
#define TIME_FORMAT "\e[1A%02d:%02d:%02d\n\r"	//Escape sequence moves the cursor up one
#define MILLISECONDS 1000	//Number of milliseconds in a second
#define MS_INC 10		//number of ms per clock pulse
#define COMMON_HOUR_START 12	//Start at 12:00:00
#define ONE_SEC_COUNT 100	//10ms count for one second
#define HALF_SECOND_COUNT 50 //10ms count for .5 seconds
#define MINUTE_OVERFLOW 60	//60 minutes/hour
#define SECOND_OVERFLOW 60	//60 seconds/minute
#define HOUR_OVERFLOW 25	//24 hours/day
#define MINUTE_UPBOUND 59	//max minutes on clock
#define SECOND_UPBOUND 59	//max seconds on clock	
#define HOUR_UPBOUND 24		//max hours on clock
#define LOWER_BOUND -1		//cannot have negative time, underflow
#define ZERO_TIME 0		//Resetting time counters to zero
//Global variable for button status
volatile rtc_button_state_t rtc_buttons;

//File scope variables
static volatile s16 seconds = ZERO_TIME; //seconds holder
static volatile s16 minutes = ZERO_TIME; //minutes holder
static volatile s16 hours = COMMON_HOUR_START; //hours holder
static volatile u32 ms; //ms counter

//State variable for state machine
static enum {
	INIT, PASS_TIME, EDIT_TIME, UP, DOWN
} state = INIT;

//Increments time and handles logic for hour/minute/second overflow
static void increment_time() {
	//if the hour button is held
	if (rtc_buttons.time.h) {
		hours++;
		//reset the hours at 25
		if (hours == HOUR_OVERFLOW)
			hours = ZERO_TIME;
	}
	//if the minute button is held
	if (rtc_buttons.time.m) {
		minutes++;
		//reset the minutes at 60
		if (minutes == MINUTE_OVERFLOW)
			minutes = ZERO_TIME;
	}
	//if the second button is held
	if (rtc_buttons.time.s) {
		seconds++;
		//reset the seconds at 60
		if (seconds == SECOND_OVERFLOW)
			seconds = ZERO_TIME;
	}
	//update time display
	xil_printf(TIME_FORMAT, hours, minutes, seconds);
}

//Decrements time and handles logic for hour/minute/second underflow
static void decrement_time() {
	//if hours button is pressed
	if (rtc_buttons.time.h) {
		hours--;
		if (hours == LOWER_BOUND)
			hours = HOUR_UPBOUND;
	}
	//if minutes button is pressed
	if (rtc_buttons.time.m) {
		minutes--;
		if (minutes == LOWER_BOUND)
			minutes = MINUTE_UPBOUND;
	}
	//if seconds button is pressed
	if (rtc_buttons.time.s) {
		seconds--;
		if (seconds == LOWER_BOUND)
			seconds = SECOND_UPBOUND;
	}
	//update time display
	xil_printf(TIME_FORMAT, hours, minutes, seconds);
}

//Init function: displays message and prints time the first time
void rtc_clock_init() {
	print(INIT_MESSAGE); //Print message
	xil_printf(TIME_FORMAT, hours, minutes, seconds); //First print of time
}

//Clock state machine tick function
void rtc_clock_tick() {
	//flag for updating the time display every second
	u16 changed = false;
	static u16 time_count;
	//state actions
	switch (state) {
	case INIT: //This state only exists for state machine consistency and philosophy.
		//It does nothing
		break;
		//increment the counter and handle H,M,S logic
	case PASS_TIME:
		ms += MS_INC;
		//roll over the ms at 1000 and add 1s
		if (ms == MILLISECONDS) {
			ms = ZERO_TIME;
			changed = true;
			//roll over the sec at 60 and add 1min
			if ((++seconds) == SECOND_OVERFLOW) {
				seconds = ZERO_TIME;
				//roll over the mins at 60 and add 1hr
				if ((++minutes) == MINUTE_OVERFLOW) {
					minutes = ZERO_TIME;
					hours++;
					//roll over the hrs at 25
					if (hours == HOUR_OVERFLOW)
						hours = ZERO_TIME;
				}
			}
		}
		//if one second has passed, update the timer display
		if (changed) {
			xil_printf(TIME_FORMAT, hours, minutes, seconds);
		}
		break;
		//
	case EDIT_TIME:
		//Do nothing inside edit time; most importantly, time is not incremented here
		break;
		//using the button struct increase the corresponding H,M,S value
	case UP:
		//after the first second has passed (set in state transition), count every half second
		//	before autoincrementing
		if (!(--time_count)) {
			time_count = HALF_SECOND_COUNT;
			increment_time();
		}
		break;
	case DOWN:
		//Same paradigm as above
		if (!(--time_count)) {
			time_count = HALF_SECOND_COUNT;
			decrement_time();
		}
		break;
	}

	//state transitions
	switch (state) {
	case INIT:
		state = PASS_TIME; //Go straight to PASS_TIME
		break;
	case PASS_TIME:
		//If any h/m/s button is pressed, go to EDIT_TIME
		if (rtc_buttons.time_button)
			state = EDIT_TIME;
		break;
	case EDIT_TIME:
		//If no h/m/s button is pressed, go back to PASS_TIME
		if (!rtc_buttons.time_button)
			state = PASS_TIME;
		else if (rtc_buttons.u) { //If up button is pressed, go to UP
			increment_time();
			time_count = ONE_SEC_COUNT; //Start counter for 1 second
			state = UP;
		} else if (rtc_buttons.d) { //If down button is pressed, go to DOWN
			decrement_time();
			time_count = ONE_SEC_COUNT; //Start counter for 1 second
			state = DOWN;
		}
		break;
	case UP:
		if (rtc_buttons.u == 0) //If up is no longer pressed, go back to EDIT_TIME
			state = EDIT_TIME;
		//If no h/m/s button is pressed, go back to PASS_TIME
		if (!rtc_buttons.time_button)
			state = PASS_TIME;
		break;
	case DOWN:
		if (rtc_buttons.d == 0) //If down is no longer pressed, go back to EDIT_TIME
			state = EDIT_TIME;
		//If no h/m/s button is pressed, go back to PASS_TIME
		if (!rtc_buttons.time_button)
			state = PASS_TIME;
		break;
	}

}
