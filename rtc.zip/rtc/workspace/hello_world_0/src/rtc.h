/*
 * rtc.h
 *
 *  Created on: Sep 21, 2017
 *      Author: Broderick Gardner and Benjamin Gardner
 */

#ifndef RTC_H_
#define RTC_H_

#include "xil_types.h"

//Struct to conveniently hold button state
typedef struct {
	union {
		struct {
			u16 h :1; //hour button state
			u16 m :1; //minute button state
			u16 s :1; //seconds button state
		} time;
		//unioned member for checking if a h/m/s button is pressed
		u16 time_button;
	};
	u16 u; //up button state
	u16 d; //down button state
} rtc_button_state_t;

//Global variables
extern volatile rtc_button_state_t rtc_buttons;

//Functions provided
void rtc_clock_tick();
void rtc_clock_init();

#endif /* RTC_H_ */
